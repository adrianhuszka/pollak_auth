import express from "express";
import cookieParser from "cookie-parser";
import path from "path"; // A statikus fájlokhoz szükséges
import { fileURLToPath } from "url"; // Az __dirname helyett szükséges

// Az aktuális fájl elérési útjának beállítása
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Middlewares
app.use(express.json());
app.use(cookieParser());
app.set("view engine", "ejs"); // Az EJS beállítása

// Statikus fájlok elérése
app.use(express.static(path.join(__dirname, "public")));

// Admin controller
import { adminController } from "./controllers/admin.controller.js";
app.use("/admin", adminController);

// Alapértelmezett útvonal
app.get("/", (req, res) => {
  res.send("Üdvözöljük az alkalmazásban! <a href='/admin/dashboard'>Admin felület</a>");
});

// A szerver indítása
app.listen(3300, () => {
  console.log("http://localhost:3300");
});
