import jwt from "jsonwebtoken";

export function verifyJwt(access_token, refresh_token) {
    jwt.verify(access_token, "test", {
        algorithm: "HS512",
        //ignoreExpiration: true,
    },
(err, decoded) => {
    console.log(decoded);
    console.error(err.message);

    if(err && err.message ==="Jwt expired") {
        const ref = verifyRefreshToken(refresh_token);
        const tokenWithIgnore = verifyWithIgnoreExpiration(access_token);

        if(ref.sub === tokenWithIgnore.sub) {

        }
         }
     }
    );
}

function verifyRefreshToken (refresh_token) {
    try {
    ret = jwt.verify(refresh_token, "test", {algorithms: "HS512"});
    } catch (err) {
        ret = null;
    }

    return ret;
}

function verifyWithIgnoreExpiration(token) {
    let ret;
    try {
        ret = jwt.verify(refresh_token, "test", {algorithms: "HS512"});
        } catch (err) {
            ret = null;
        }
    
        return ret;
}

function createNewToken(nev, email, groupsNeve) {
    return jwt.sign(
    {
        sub: id,
        name: nev,
        email: email,
        userGroup: groupsNeve,
      },
      "test",
      {
          expiresIn: "5m",
          algorithm: "HS512",
      }
    );
}
