import express from "express";
import bcrypt from "bcryptjs";  // A bcryptjs importálása

const router = express.Router();

// A felhasználók listája, amit statikus adatokként tárolunk
let users = [
  { id: 1, username: "admin", role: "admin", email: "admin@admin.com", password: "admin123" },
  { id: 2, username: "user", role: "user", email: "user@gmail.com", password: "user123" },
  { id: 3, username: "zeten1ga", role: "user", email: "zetecigany@citromail.hu", password: "zeten123" }
];

// Admin dashboard oldal
router.get("/dashboard", (req, res) => {
  res.render("admin/dashboard", { users });
});

// Felhasználó törlése
router.post("/user/delete/:id", (req, res) => {
  const userId = parseInt(req.params.id, 10);
  users = users.filter(user => user.id !== userId); // Töröljük a felhasználót
  res.redirect("/admin/dashboard");
});

// Felhasználó módosítása - GET kérés
router.get("/user/edit/:id", (req, res) => {
  const userId = parseInt(req.params.id, 10);
  const user = users.find(user => user.id === userId);
  if (user) {
    res.render("admin/edit-user", { user });
  } else {
    res.redirect("/admin/dashboard");
  }
});

// Felhasználó módosítása - POST kérés
router.post("/user/edit/:id", async (req, res) => {
  const { username, email, role, password } = req.body;
  const userId = parseInt(req.params.id, 10);
  const userIndex = users.findIndex(user => user.id === userId);
  
  if (userIndex !== -1) {
    // Ha van új jelszó, akkor titkosítjuk
    const hashedPassword = password ? await bcrypt.hash(password, 10) : users[userIndex].password;
    
    users[userIndex] = { 
      id: userId, 
      username, 
      email, 
      role, 
      password: hashedPassword 
    }; // Felhasználó módosítása
  }
  res.redirect("/admin/dashboard");
});

// Új felhasználó oldal (GET kérés)
router.get("/user/new", (req, res) => {
  res.render("admin/new-user");
});

// Új felhasználó hozzáadása (POST kérés)
router.post("/user/new", async (req, res) => {
  const { username, email, role, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10); // Új jelszó titkosítása

  const newUser = {
    id: users.length + 1, // Új ID generálása
    username,
    email,
    role,
    password: hashedPassword
  };
  users.push(newUser); // Felhasználó hozzáadása
  res.redirect("/admin/dashboard");
});

// Random jelszó generálása
router.get("/user/random-password", (req, res) => {
  const randomPassword = Math.random().toString(36).slice(-8); // Generálj egy 8 karakter hosszú véletlenszerű jelszót
  res.json({ password: randomPassword });
});

export { router as adminController };
